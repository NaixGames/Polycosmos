# Bk Sudoku

## What is this game?

BK Sudoku is not a typical Archipelago game; instead, it is a generic Sudoku client that can connect to any existing multiworld. When connected, you can play Sudoku to unlock random hints for your game. While slow, it will give you something to do when you can't reach the checks in your game.

## What hints are unlocked?

After completing a Sudoku puzzle, the game will unlock 1 random hint for an unchecked location in the slot you are connected to.

## Where is the settings page?

There is no settings page; this game cannot be used in your .yamls. Instead, the client can connect to any slot in a multiworld.
