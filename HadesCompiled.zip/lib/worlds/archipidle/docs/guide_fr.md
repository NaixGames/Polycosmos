# Guide de configuration d'ArchipIdle

## Rejoindre une partie MultiWorld
1. Générez un fichier `.yaml` à partir de la [page des paramètres du lecteur ArchipIDLE](/games/ArchipIDLE/player-settings)
2. Ouvrez le client ArchipIDLE dans votre navigateur Web en :
     - Accédez au [Client ArchipIDLE](http://idle.multiworld.link)
     - Téléchargez le client et exécutez-le localement à partir du
       [Page des versions d'ArchipIDLE GitHub](https://github.com/ArchipelagoMW/archipidle/releases)
3. Entrez l'adresse du serveur dans le champ `Server Address` et appuyez sur Entrée
4. Entrez votre nom d'emplacement lorsque vous y êtes invité. Il doit être le même que le `name` que vous avez saisi sur le
    page de configuration ci-dessus, ou le champ `name` dans votre fichier yaml.
5. Cliquez sur "Commencer !" bouton.
