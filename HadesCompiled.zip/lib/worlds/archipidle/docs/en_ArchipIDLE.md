# ArchipIDLE

## What is this game?

ArchipIDLE was originally the 2022 Archipelago April Fools' Day joke. It is an idle game that sends a location check
on regular intervals. Updated annually with more items, gimmicks, and features, the game is visible
only during the month of April.

## Where is the settings page?

The [player settings page for this game](../player-settings) contains all the options you need to configure
and export a config file.

