# SC2 Bot
This is client library to communicate with Starcraft 2 game  
It's based on `burnysc2` python package, see https://github.com/BurnySc2/python-sc2

The base package is stripped down to clean up unneeded features and those not working outside a
melee game.
