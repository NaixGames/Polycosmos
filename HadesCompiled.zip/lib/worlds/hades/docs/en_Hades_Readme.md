# Hades (PC)


## What does randomization do to this game?

Players start with Pact of Punishments forced to be on, making the game harder. Completing any room for the first
time counts as a location check, unlocking a new item. 

## What is the goal of the game?

To beat Hades once. In the future we will implement customization options to allow for other goals.

## Do I need to start from a fresh file or a completed one?

The randomizer is intended to use on a fresh file. However, it stills works on a completed one assuming you start from 
house of Hades and you do not change the seting on the pact of punishment window.

## What items and locations get shuffled?

Every pact of punishment that is turned on is suffled as a item in the pool. Obtaining that item turns off that pact of
punishment, allowing for more progression on the runs. Also filler items are shuffled, which includes Darkness, Keys,
Gemstones, Diamonds, Titan Blood, Nectar and Ambrosia.

## Which items can be in another player's world?

Any of the items which can be shuffled may also be placed into another player's world. 

## When the player receives an item, what happens?

When the player recieve a filler item you will recieve a message in the game telling you how much of the filler item you got.
If you recieve a pact of punishment item you will see the heat level going down. it is plan for pacts of punishment to include 
a console message in the near future.

## What settings can I change in the .yalm?

You can choose how many pact of pushmients starts on when you play the game, changing how many pact of punishements items
are suffled in the pool. More of them mae the game harder. You can also choose the value of filler items, with the option of 
them having 0 value, removing them from the pool.
