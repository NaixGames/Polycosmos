ConditionalItemData.SwordWeaponUnlock =
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 1,
}
ConditionalItemData.SpearWeaponUnlock = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 4,
}
ConditionalItemData.ShieldWeaponUnlock = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 3,
}
ConditionalItemData.BowWeaponUnlock = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 1,
}
ConditionalItemData.FistWeaponUnlock = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 8,
}
ConditionalItemData.GunWeaponUnlock = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 8,
}