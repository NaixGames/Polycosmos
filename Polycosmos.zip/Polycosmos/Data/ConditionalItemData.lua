ConditionalItemData["Sword Weapon Unlock"] =
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 1,
}
ConditionalItemData["Spear Weapon Unlock"] = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 4,
}
ConditionalItemData["Shield Weapon Unlock"] = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 3,
}
ConditionalItemData["Bow Weapon Unlock"] = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 1,
}
ConditionalItemData["Fist Weapon Unlock"] = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 8,
}
ConditionalItemData["Gun Weapon Unlock"] = 
{
    InheritFrom = { "DefaultCriticalItem" },
    ResourceName = "LockKeys",
    ResourceCost = 8,
}